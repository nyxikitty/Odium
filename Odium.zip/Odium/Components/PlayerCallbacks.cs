﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VRC;

namespace Odium.Components
{
    internal class playerCallbacks
    {
        private static readonly List<playerCallbacks> RegisteredCallbacks = new List<playerCallbacks>();

        public playerCallbacks()
        {
            RegisteredCallbacks.Add(this);
        }

        public virtual void OnPlayerJoined(Player player) { }
        public virtual void OnPlayerLeft(Player player) { }
        public static void HandlePlayerJoin(Player player)
        {
            foreach (var callback in RegisteredCallbacks)
            {
                try
                {
                    callback.OnPlayerJoined(player);
                }
                catch (Exception ex)
                {
                    OdiumConsole.LogGradient("CallbackError", $"OnPlayerJoined: {ex.Message}");
                }
            }
        }

        public static void HandlePlayerLeave(Player player)
        {
            foreach (var callback in RegisteredCallbacks)
            {
                try
                {
                    callback.OnPlayerLeft(player);
                }
                catch (Exception ex)
                {
                    OdiumConsole.LogGradient("CallbackError", $"OnPlayerLeft: {ex.Message}");
                }
            }
        }
    }
}
