﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using VRC.SDKBase;
using Odium.Wrappers;
using Odium.UX;
using UnhollowerBaseLib;
using UnhollowerRuntimeLib;

namespace Odium.Components
{
    public static class CustomPlayerList
    {
        private static bool showPlayerList = false;
        private static Vector2 scrollPosition = Vector2.zero;
        private static int selectedPlayerId = 0;
        private static Rect windowRect = new Rect(20, 20, 380, 600);
        private static string searchFilter = "";
        private static bool showAdvancedOptions = false;
        private static float animationTime = 0f;

        // Enhanced GUI Styles
        private static GUIStyle windowStyle;
        private static GUIStyle playerButtonStyle;
        private static GUIStyle localPlayerButtonStyle;
        private static GUIStyle selectedPlayerButtonStyle;
        private static GUIStyle actionButtonStyle;
        private static GUIStyle primaryActionButtonStyle;
        private static GUIStyle dangerActionButtonStyle;
        private static GUIStyle headerStyle;
        private static GUIStyle subHeaderStyle;
        private static GUIStyle searchFieldStyle;
        private static GUIStyle statusLabelStyle;
        private static GUIStyle separatorStyle;
        private static bool stylesInitialized = false;

        // Color scheme
        private static readonly Color primaryColor = new Color(0.2f, 0.3f, 0.8f, 1f);
        private static readonly Color secondaryColor = new Color(0.15f, 0.15f, 0.2f, 1f);
        private static readonly Color accentColor = new Color(0.3f, 0.7f, 1f, 1f);
        private static readonly Color successColor = new Color(0.2f, 0.8f, 0.3f, 1f);
        private static readonly Color warningColor = new Color(1f, 0.6f, 0.2f, 1f);
        private static readonly Color dangerColor = new Color(0.9f, 0.3f, 0.3f, 1f);
        private static readonly Color backgroundColor = new Color(0.08f, 0.08f, 0.12f, 0.95f);

        public static void TogglePlayerList()
        {
            showPlayerList = !showPlayerList;
            if (showPlayerList)
            {
                animationTime = 0f;
                selectedPlayerId = 0;
                searchFilter = "";
            }
        }

        public static void OnGUI()
        {
            if (!showPlayerList) return;

            InitializeStyles();
            animationTime += Time.deltaTime;

            // Fade-in animation
            float alpha = Mathf.Clamp01(animationTime * 3f);
            Color guiColor = GUI.color;
            GUI.color = new Color(guiColor.r, guiColor.g, guiColor.b, alpha);

            // Create the window function as an Action<int>
            System.Action<int> windowFunction = new System.Action<int>(DrawPlayerListWindow);

            // Draw the player list window with enhanced styling
            windowRect = GUI.Window(12345, windowRect, DelegateSupport.ConvertDelegate<GUI.WindowFunction>(windowFunction), "", windowStyle);

            GUI.color = guiColor;
        }

        private static void InitializeStyles()
        {
            if (stylesInitialized) return;

            // Enhanced window style
            windowStyle = new GUIStyle(GUI.skin.window);
            windowStyle.normal.background = CreateTexture(backgroundColor);
            windowStyle.border = new RectOffset(12, 12, 12, 12);
            windowStyle.padding = new RectOffset(15, 15, 20, 15);

            // Enhanced player button styles
            playerButtonStyle = new GUIStyle(GUI.skin.button);
            playerButtonStyle.alignment = TextAnchor.MiddleLeft;
            playerButtonStyle.normal.background = CreateTexture(new Color(0.2f, 0.2f, 0.25f, 1f));
            playerButtonStyle.hover.background = CreateTexture(new Color(0.25f, 0.25f, 0.3f, 1f));
            playerButtonStyle.active.background = CreateTexture(new Color(0.15f, 0.15f, 0.2f, 1f));
            playerButtonStyle.normal.textColor = Color.white;
            playerButtonStyle.hover.textColor = accentColor;
            playerButtonStyle.padding = new RectOffset(12, 12, 8, 8);
            playerButtonStyle.margin = new RectOffset(0, 0, 2, 2);
            playerButtonStyle.border = new RectOffset(2, 2, 2, 2);

            // Local player style
            localPlayerButtonStyle = new GUIStyle(playerButtonStyle);
            localPlayerButtonStyle.normal.background = CreateTexture(new Color(successColor.r * 0.3f, successColor.g * 0.3f, successColor.b * 0.3f, 1f));
            localPlayerButtonStyle.hover.background = CreateTexture(new Color(successColor.r * 0.4f, successColor.g * 0.4f, successColor.b * 0.4f, 1f));
            localPlayerButtonStyle.normal.textColor = successColor;
            localPlayerButtonStyle.fontStyle = FontStyle.Bold;

            // Selected player style
            selectedPlayerButtonStyle = new GUIStyle(playerButtonStyle);
            selectedPlayerButtonStyle.normal.background = CreateTexture(new Color(accentColor.r * 0.3f, accentColor.g * 0.3f, accentColor.b * 0.3f, 1f));
            selectedPlayerButtonStyle.hover.background = CreateTexture(new Color(accentColor.r * 0.4f, accentColor.g * 0.4f, accentColor.b * 0.4f, 1f));
            selectedPlayerButtonStyle.normal.textColor = accentColor;

            // Enhanced action button styles
            actionButtonStyle = new GUIStyle(GUI.skin.button);
            actionButtonStyle.normal.background = CreateTexture(new Color(0.3f, 0.3f, 0.35f, 1f));
            actionButtonStyle.hover.background = CreateTexture(new Color(0.4f, 0.4f, 0.45f, 1f));
            actionButtonStyle.active.background = CreateTexture(new Color(0.25f, 0.25f, 0.3f, 1f));
            actionButtonStyle.normal.textColor = Color.white;
            actionButtonStyle.hover.textColor = accentColor;
            actionButtonStyle.padding = new RectOffset(8, 8, 6, 6);
            actionButtonStyle.margin = new RectOffset(2, 2, 1, 1);
            actionButtonStyle.fontSize = 11;

            // Primary action button style
            primaryActionButtonStyle = new GUIStyle(actionButtonStyle);
            primaryActionButtonStyle.normal.background = CreateTexture(new Color(primaryColor.r * 0.8f, primaryColor.g * 0.8f, primaryColor.b * 0.8f, 1f));
            primaryActionButtonStyle.hover.background = CreateTexture(primaryColor);
            primaryActionButtonStyle.normal.textColor = Color.white;
            primaryActionButtonStyle.fontStyle = FontStyle.Bold;

            // Danger action button style
            dangerActionButtonStyle = new GUIStyle(actionButtonStyle);
            dangerActionButtonStyle.normal.background = CreateTexture(new Color(dangerColor.r * 0.6f, dangerColor.g * 0.6f, dangerColor.b * 0.6f, 1f));
            dangerActionButtonStyle.hover.background = CreateTexture(dangerColor);
            dangerActionButtonStyle.normal.textColor = Color.white;

            // Enhanced header styles
            headerStyle = new GUIStyle(GUI.skin.label);
            headerStyle.alignment = TextAnchor.MiddleCenter;
            headerStyle.fontStyle = FontStyle.Bold;
            headerStyle.fontSize = 16;
            headerStyle.normal.textColor = accentColor;
            headerStyle.padding = new RectOffset(0, 0, 10, 10);

            subHeaderStyle = new GUIStyle(GUI.skin.label);
            subHeaderStyle.alignment = TextAnchor.MiddleLeft;
            subHeaderStyle.fontStyle = FontStyle.Bold;
            subHeaderStyle.fontSize = 12;
            subHeaderStyle.normal.textColor = new Color(0.8f, 0.8f, 0.9f, 1f);
            subHeaderStyle.padding = new RectOffset(5, 5, 5, 5);

            // Search field style
            searchFieldStyle = new GUIStyle(GUI.skin.textField);
            searchFieldStyle.normal.background = CreateTexture(new Color(0.15f, 0.15f, 0.2f, 1f));
            searchFieldStyle.focused.background = CreateTexture(new Color(0.2f, 0.2f, 0.25f, 1f));
            searchFieldStyle.normal.textColor = Color.white;
            searchFieldStyle.focused.textColor = accentColor;
            searchFieldStyle.padding = new RectOffset(10, 10, 8, 8);
            searchFieldStyle.border = new RectOffset(2, 2, 2, 2);

            // Status label style
            statusLabelStyle = new GUIStyle(GUI.skin.label);
            statusLabelStyle.alignment = TextAnchor.MiddleCenter;
            statusLabelStyle.fontSize = 11;
            statusLabelStyle.normal.textColor = new Color(0.7f, 0.7f, 0.8f, 1f);

            // Separator style
            separatorStyle = new GUIStyle();
            separatorStyle.normal.background = CreateTexture(new Color(0.3f, 0.3f, 0.4f, 1f));
            separatorStyle.margin = new RectOffset(5, 5, 5, 5);

            stylesInitialized = true;
        }

        private static Texture2D CreateTexture(Color color)
        {
            Texture2D texture = new Texture2D(1, 1);
            texture.SetPixel(0, 0, color);
            texture.Apply();
            return texture;
        }

        private static void DrawPlayerListWindow(int windowID)
        {
            GUILayout.BeginVertical(new Il2CppReferenceArray<GUILayoutOption>(0));

            // Header with glow effect
            DrawHeader();

            // Search and filters
            DrawSearchAndFilters();

            // Player count and stats
            DrawPlayerStats();

            // Separator
            GUILayout.Box("", separatorStyle, new Il2CppReferenceArray<GUILayoutOption>(1) { [0] = GUILayout.Height(1) });

            // Scroll view for players with enhanced styling
            GUILayout.Label("Players", subHeaderStyle, new Il2CppReferenceArray<GUILayoutOption>(0));

            scrollPosition = GUILayout.BeginScrollView(
                scrollPosition,
                false,
                true,
                GUI.skin.horizontalScrollbar,
                GUI.skin.verticalScrollbar,
                GUI.skin.scrollView,
                new Il2CppReferenceArray<GUILayoutOption>(1) { [0] = GUILayout.Height(380) }
            );

            DrawPlayerEntries();

            GUILayout.EndScrollView();

            // Bottom controls
            DrawBottomControls();

            GUILayout.EndVertical();

            // Make window draggable
            GUI.DragWindow();
        }

        private static void DrawHeader()
        {
            // Animated header with gradient effect
            float pulseAlpha = 0.8f + 0.2f * Mathf.Sin(animationTime * 2f);
            Color headerColor = new Color(accentColor.r, accentColor.g, accentColor.b, pulseAlpha);

            Color oldColor = GUI.contentColor;
            GUI.contentColor = headerColor;

            GUILayout.Label("◉ ODIUM PLAYER LIST", headerStyle, new Il2CppReferenceArray<GUILayoutOption>(0));

            GUI.contentColor = oldColor;
        }

        private static void DrawSearchAndFilters()
        {
            GUILayout.BeginHorizontal(new Il2CppReferenceArray<GUILayoutOption>(0));

            GUILayout.Label("🔍", new Il2CppReferenceArray<GUILayoutOption>(1) { [0] = GUILayout.Width(20) });
            searchFilter = GUILayout.TextField(searchFilter, searchFieldStyle, new Il2CppReferenceArray<GUILayoutOption>(1) { [0] = GUILayout.ExpandWidth(true) });

            // Clear search button
            if (GUILayout.Button("✕", actionButtonStyle, new Il2CppReferenceArray<GUILayoutOption>(1) { [0] = GUILayout.Width(25) }))
            {
                searchFilter = "";
            }

            GUILayout.EndHorizontal();

            GUILayout.Space(5);
        }

        private static void DrawPlayerStats()
        {
            var players = GetAllPlayers();
            var filteredPlayers = GetFilteredPlayers(players);

            string statsText = $"Total: {players.Count} | Showing: {filteredPlayers.Count} | Selected: {(selectedPlayerId > 0 ? "1" : "0")}";
            GUILayout.Label(statsText, statusLabelStyle, new Il2CppReferenceArray<GUILayoutOption>(0));
        }

        private static void DrawPlayerEntries()
        {
            var players = GetFilteredPlayers(GetAllPlayers());

            if (players.Count == 0)
            {
                GUILayout.Space(50);
                GUILayout.Label("No players found", statusLabelStyle, new Il2CppReferenceArray<GUILayoutOption>(0));
                return;
            }

            foreach (var player in players)
            {
                if (player?.prop_VRCPlayerApi_0 == null) continue;

                int playerId = player.field_Private_VRCPlayerApi_0.playerId;
                string playerName = player.prop_VRCPlayerApi_0.displayName;
                bool isLocal = player.prop_VRCPlayerApi_0.isLocal;
                bool isExpanded = selectedPlayerId == playerId;

                // Choose appropriate button style
                GUIStyle buttonStyle = isLocal ? localPlayerButtonStyle :
                                     isExpanded ? selectedPlayerButtonStyle : playerButtonStyle;

                // Player entry with enhanced styling
                string displayName = isLocal ? $"👤 {playerName} (YOU)" : $"👥 {playerName}";

                if (GUILayout.Button(displayName, buttonStyle, new Il2CppReferenceArray<GUILayoutOption>(1) { [0] = GUILayout.Height(28) }))
                {
                    selectedPlayerId = isExpanded ? 0 : playerId;
                }

                // Expanded actions panel
                if (isExpanded && !isLocal)
                {
                    DrawEnhancedPlayerActions(playerId, playerName);
                }
            }
        }

        private static void DrawEnhancedPlayerActions(int playerId, string playerName)
        {
            // Enhanced actions panel with better organization
            GUILayout.BeginVertical(GUI.skin.box, new Il2CppReferenceArray<GUILayoutOption>(0));

            GUILayout.Label($"Actions for {playerName}", subHeaderStyle, new Il2CppReferenceArray<GUILayoutOption>(0));
            GUILayout.Space(5);

            // Movement actions
            GUILayout.Label("Movement", statusLabelStyle, new Il2CppReferenceArray<GUILayoutOption>(0));
            GUILayout.BeginHorizontal(new Il2CppReferenceArray<GUILayoutOption>(0));
            if (GUILayout.Button("📍 Teleport To", primaryActionButtonStyle, new Il2CppReferenceArray<GUILayoutOption>(1) { [0] = GUILayout.Height(22) }))
            {
                ExecuteTeleportTo(playerId, playerName);
            }
            if (GUILayout.Button("🔄 Bring Here", actionButtonStyle, new Il2CppReferenceArray<GUILayoutOption>(1) { [0] = GUILayout.Height(22) }))
            {
                ExecuteBringHere(playerId, playerName);
            }
            GUILayout.EndHorizontal();

            GUILayout.Space(3);

            // Special actions
            GUILayout.Label("Effects", statusLabelStyle, new Il2CppReferenceArray<GUILayoutOption>(0));
            GUILayout.BeginHorizontal(new Il2CppReferenceArray<GUILayoutOption>(0));
            if (GUILayout.Button("🌀 Portal Spam", dangerActionButtonStyle, new Il2CppReferenceArray<GUILayoutOption>(1) { [0] = GUILayout.Height(22) }))
            {
                ExecuteBlock(playerId, playerName);
            }
            if (GUILayout.Button("🚁 Drone Swarm", dangerActionButtonStyle, new Il2CppReferenceArray<GUILayoutOption>(1) { [0] = GUILayout.Height(22) }))
            {
                ExecuteMute(playerId, playerName);
            }
            GUILayout.EndHorizontal();

            GUILayout.Space(3);

            // Utility actions
            GUILayout.Label("Utilities", statusLabelStyle, new Il2CppReferenceArray<GUILayoutOption>(0));
            GUILayout.BeginHorizontal(new Il2CppReferenceArray<GUILayoutOption>(0));
            if (GUILayout.Button("📋 Copy ID", actionButtonStyle, new Il2CppReferenceArray<GUILayoutOption>(1) { [0] = GUILayout.Height(22) }))
            {
                ExecuteCopyId(playerId, playerName);
            }
            if (GUILayout.Button("📝 Copy Name", actionButtonStyle, new Il2CppReferenceArray<GUILayoutOption>(1) { [0] = GUILayout.Height(22) }))
            {
                ExecuteCopyName(playerId, playerName);
            }
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal(new Il2CppReferenceArray<GUILayoutOption>(0));
            if (GUILayout.Button("🌐 Send Portal", primaryActionButtonStyle, new Il2CppReferenceArray<GUILayoutOption>(1) { [0] = GUILayout.Height(22) }))
            {
                ExecuteSendPortal(playerId, playerName);
            }
            if (GUILayout.Button("⚙️ Custom", actionButtonStyle, new Il2CppReferenceArray<GUILayoutOption>(1) { [0] = GUILayout.Height(22) }))
            {
                ExecuteCustomAction(playerId, playerName);
            }
            GUILayout.EndHorizontal();

            GUILayout.EndVertical();
            GUILayout.Space(3);
        }

        private static void DrawBottomControls()
        {
            GUILayout.Space(5);

            // Advanced options toggle
            GUILayout.BeginHorizontal(new Il2CppReferenceArray<GUILayoutOption>(0));

            if (GUILayout.Button($"{(showAdvancedOptions ? "🔽" : "▶️")} Advanced", actionButtonStyle, new Il2CppReferenceArray<GUILayoutOption>(1) { [0] = GUILayout.Height(25) }))
            {
                showAdvancedOptions = !showAdvancedOptions;
            }

            GUILayout.FlexibleSpace();

            // Close button with enhanced styling
            if (GUILayout.Button("❌ Close", dangerActionButtonStyle, new Il2CppReferenceArray<GUILayoutOption>(1) { [0] = GUILayout.Height(25) }))
            {
                showPlayerList = false;
            }

            GUILayout.EndHorizontal();

            // Advanced options panel
            if (showAdvancedOptions)
            {
                GUILayout.Space(5);
                GUILayout.BeginVertical(GUI.skin.box, new Il2CppReferenceArray<GUILayoutOption>(0));
                GUILayout.Label("Advanced Options", subHeaderStyle, new Il2CppReferenceArray<GUILayoutOption>(0));

                GUILayout.BeginHorizontal(new Il2CppReferenceArray<GUILayoutOption>(0));
                if (GUILayout.Button("🔄 Refresh List", actionButtonStyle, new Il2CppReferenceArray<GUILayoutOption>(0)))
                {
                    // Refresh logic here
                    selectedPlayerId = 0;
                }
                if (GUILayout.Button("📊 Export Data", actionButtonStyle, new Il2CppReferenceArray<GUILayoutOption>(0)))
                {
                    // Export logic here
                }
                GUILayout.EndHorizontal();

                GUILayout.EndVertical();
            }
        }

        private static List<VRC.Player> GetFilteredPlayers(List<VRC.Player> players)
        {
            if (string.IsNullOrEmpty(searchFilter))
                return players;

            return players.Where(p => p?.prop_VRCPlayerApi_0?.displayName != null &&
                                    p.prop_VRCPlayerApi_0.displayName.ToLower().Contains(searchFilter.ToLower())).ToList();
        }

        #region Action Methods (Keep original implementations)

        private static void ExecuteTeleportTo(int playerId, string playerName)
        {
            try
            {
                OdiumConsole.LogGradient("PlayerList", $"Teleporting to {playerName} (ID: {playerId})");

                var targetPlayer = PlayerWrapper.GetVRCPlayerFromPhotonId(playerId);
                if (targetPlayer?._player?.transform != null)
                {
                    var localPlayer = VRCPlayer.field_Internal_Static_VRCPlayer_0;
                    if (localPlayer != null)
                    {
                        localPlayer.transform.position = targetPlayer._player.transform.position;
                        localPlayer.transform.rotation = targetPlayer._player.transform.rotation;
                    }
                }
            }
            catch (System.Exception ex)
            {
                OdiumConsole.Log("Error", $"Failed to teleport to {playerName}: {ex.Message}", LogLevel.Error);
            }
        }

        private static void ExecuteBringHere(int playerId, string playerName)
        {
            try
            {
                OdiumConsole.LogGradient("PlayerList", $"Bringing {playerName} here (ID: {playerId})");
                // Add your bring here logic
                // Note: This typically requires special permissions in VRChat
            }
            catch (System.Exception ex)
            {
                OdiumConsole.Log("Error", $"Failed to bring {playerName}: {ex.Message}", LogLevel.Error);
            }
        }

        private static void ExecuteBlock(int playerId, string playerName)
        {
            try
            {
                OdiumConsole.LogGradient("PlayerList", $"Portal spam for {playerName} (ID: {playerId})");

                var targetPlayer = PlayerWrapper.GetVRCPlayerFromPhotonId(playerId);
                if (targetPlayer?.prop_VRCPlayerApi_0 != null)
                {
                    if (ActionWrapper.portalSpam)
                    {
                        ActionWrapper.portalSpam = false;
                        ActionWrapper.portalSpamPlayer = null;
                        InternalConsole.LogIntoConsole($"Disabled portal spam");
                    }
                    else
                    {
                        ActionWrapper.portalSpam = true;
                        ActionWrapper.portalSpamPlayer = targetPlayer.prop_Player_0;
                        InternalConsole.LogIntoConsole($"Enabled portal spam");
                    }
                }
            }
            catch (System.Exception ex)
            {
                OdiumConsole.Log("Error", $"Failed to execute portal spam for {playerName}: {ex.Message}", LogLevel.Error);
            }
        }

        private static void ExecuteMute(int playerId, string playerName)
        {
            try
            {
                OdiumConsole.LogGradient("PlayerList", $"Drone swarm for {playerName} (ID: {playerId})");

                var targetPlayer = PlayerWrapper.GetVRCPlayerFromPhotonId(playerId);
                if (targetPlayer?.prop_VRCPlayerApi_0 != null)
                {
                    if (DroneSwarmWrapper.isSwarmActive)
                    {
                        DroneSwarmWrapper.StopDroneSwarm();
                        InternalConsole.LogIntoConsole($"Disabled drone swarm");
                    }
                    else
                    {
                        DroneSwarmWrapper.StartDroneSwarm(targetPlayer.prop_Player_0.gameObject, 2.6f);
                        InternalConsole.LogIntoConsole($"Enabled drone swarm");
                    }
                }
            }
            catch (System.Exception ex)
            {
                OdiumConsole.Log("Error", $"Failed to execute drone swarm for {playerName}: {ex.Message}", LogLevel.Error);
            }
        }

        private static void ExecuteCopyId(int playerId, string playerName)
        {
            try
            {
                GUIUtility.systemCopyBuffer = playerId.ToString();
                OdiumConsole.LogGradient("PlayerList", $"Copied {playerName}'s ID to clipboard: {playerId}");
            }
            catch (System.Exception ex)
            {
                OdiumConsole.Log("Error", $"Failed to copy ID: {ex.Message}", LogLevel.Error);
            }
        }

        private static void ExecuteCopyName(int playerId, string playerName)
        {
            try
            {
                GUIUtility.systemCopyBuffer = playerName;
                OdiumConsole.LogGradient("PlayerList", $"Copied name to clipboard: {playerName}");
            }
            catch (System.Exception ex)
            {
                OdiumConsole.Log("Error", $"Failed to copy name: {ex.Message}", LogLevel.Error);
            }
        }

        private static void ExecuteSendPortal(int playerId, string playerName)
        {
            try
            {
                OdiumConsole.LogGradient("PlayerList", $"Sending portal to {playerName} (ID: {playerId})");
                // Add your portal sending logic here
            }
            catch (System.Exception ex)
            {
                OdiumConsole.Log("Error", $"Failed to send portal to {playerName}: {ex.Message}", LogLevel.Error);
            }
        }

        private static void ExecuteCustomAction(int playerId, string playerName)
        {
            try
            {
                OdiumConsole.LogGradient("PlayerList", $"Custom action for {playerName} (ID: {playerId})");
                // Add your custom action logic here
            }
            catch (System.Exception ex)
            {
                OdiumConsole.Log("Error", $"Failed to execute custom action for {playerName}: {ex.Message}", LogLevel.Error);
            }
        }

        #endregion

        #region Helper Methods

        private static List<VRC.Player> GetAllPlayers()
        {
            return PlayerWrapper.Players;
        }

        private static int GetPlayerCount()
        {
            try
            {
                return PlayerWrapper.Players.Count;
            }
            catch
            {
                return 0;
            }
        }

        #endregion
    }
}