﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odium.Wrappers
{
    class PortalWrapper
    {
        public static void SpawnPortal(UnityEngine.Vector3 positon, string worldSecureCode)
        {
            ObjectPublicAbstractSealedSiInSiUIBoSiGaTrDi2Unique.Method_Public_Static_Boolean_String_Boolean_Vector3_Quaternion_String_Action_1_LocalizableString_0(worldSecureCode, true, positon, new UnityEngine.Quaternion(0, 0, 0, 0));
        }
    }
}
