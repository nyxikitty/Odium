﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odium.Wrappers
{
    internal class ActionWrapper
    {
        public static VRC.Player portalSpamPlayer;
        public static bool portalSpam;

        public static VRC.Player portalTrapPlayer;
        public static bool portalTrap;
        public static bool massPortalSpam;
        public static bool serialize;

        public static VRC.Player attachTarget;

    }
}
