﻿using ExitGames.Client.Photon;
using HarmonyLib;
using Odium.ApplicationBot;
using Odium.Components;
using Odium.Modules;
using Odium.UX;
using Odium.Wrappers;
using Photon.Realtime;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnhollowerBaseLib;
using UnityEngine;

namespace Odium.Patches
{
    [HarmonyPatch(typeof(LoadBalancingClient))]
    public class PhotonPatches
    {
        public static bool BlockUdon = false;

        private static Dictionary<int, bool> blocks = new Dictionary<int, bool>();
        private static Dictionary<int, bool> mutes = new Dictionary<int, bool>();

        [HarmonyPrefix]
        [HarmonyPatch("OnEvent")]
        static bool OnEvent(LoadBalancingClient __instance, EventData param_1)
        {
            var eventCode = param_1.Code;
            switch (eventCode)
            {
                case 12:
                    if (Bot.movementMimic && Bot.movementMimicActorNr != 0 && Bot.movementMimicActorNr == param_1.sender)
                    {
                        PhotonExtensions.OpRaiseEvent(12, param_1.customData, new RaiseEventOptions
                        {
                            field_Public_EventCaching_0 = EventCaching.DoNotCache,
                            field_Public_ReceiverGroup_0 = ReceiverGroup.Others
                        }, default(SendOptions));
                        return false;
                    }
                    break;
                case 11:
                    if (BlockUdon)
                    {
                        InternalConsole.LogIntoConsole(
                            $"<color=#31BCF0>[Udon]:</color> Event <color=#00AAFF>blocked</color>!"
                        );
                        return false;
                    }
                    break;

                case 33:
                    OdiumConsole.LogGradient("PhotonEvent", $"Moderation Event - Code: {param_1.Code}");

                    if (param_1.Parameters != null && param_1.Parameters.ContainsKey(245))
                    {
                        var moderationDict = param_1.Parameters[245]
                            .TryCast<Il2CppSystem.Collections.Generic.Dictionary<byte, Il2CppSystem.Object>>();

                        if (moderationDict != null)
                        {
                            OdiumConsole.LogGradient("PhotonEvent", $"Moderation Dictionary found with {moderationDict.Count} items");

                            if (moderationDict.ContainsKey(0))
                            {
                                var moderationType = moderationDict[0].Unbox<byte>();
                                OdiumConsole.LogGradient("PhotonEvent", $"  Moderation Type: {moderationType}");
                            }

                            if (moderationDict.ContainsKey(1))
                            {
                                var playerId = moderationDict[1].Unbox<int>();
                                OdiumConsole.LogGradient("PhotonEvent", $"  Player ID: {playerId}");

                                if (moderationDict.ContainsKey(10))
                                {
                                    var blockStatus = moderationDict[10].Unbox<bool>();
                                    OdiumConsole.LogGradient("PhotonEvent", $"  *** BLOCK STATUS: {(blockStatus ? "BLOCKED" : "UNBLOCKED")} ***");

                                    if (!blocks.ContainsKey(playerId) || blocks[playerId] != blockStatus)
                                    {
                                        blocks[playerId] = blockStatus;

                                        if (blockStatus == true)
                                        {
                                            VRCPlayer player = PlayerWrapper.GetPlayerFromPhotonId(playerId);
                                            Chatbox.SendCustomChatMessage($"[Odium] -> {player.field_Private_VRCPlayerApi_0.displayName} BLOCKED me");
                                            OdiumBottomNotification.ShowNotification($"<color=#7B02FE>{player.field_Private_VRCPlayerApi_0.displayName}</color> <color=red>BLOCKED</color> you!");
                                            InternalConsole.LogIntoConsole(
                                                $"<color=#31BCF0>[Odium]:</color> <color=#7B02FE>{player.field_Private_VRCPlayerApi_0.displayName}</color> <color=red>BLOCKED</color> you!"
                                            );
                                        }
                                        else
                                        {
                                            VRCPlayer player = PlayerWrapper.GetPlayerFromPhotonId(playerId);
                                            Chatbox.SendCustomChatMessage($"[Odium] -> {player.field_Private_VRCPlayerApi_0.displayName} UNBLOCKED me");
                                            OdiumBottomNotification.ShowNotification($"<color=#7B02FE>{player.field_Private_VRCPlayerApi_0.displayName}</color> <color=red>UNBLOCKED</color> you!");
                                            InternalConsole.LogIntoConsole(
                                                $"<color=#31BCF0>[Odium]:</color> <color=#7B02FE>{player.field_Private_VRCPlayerApi_0.displayName}</color> <color=red>UNBLOCKED</color> you!"
                                            );
                                        }
                                    }
                                }

                                if (moderationDict.ContainsKey(11))
                                {
                                    var muteStatus = moderationDict[11].Unbox<bool>();
                                    OdiumConsole.LogGradient("PhotonEvent", $"  Mute Status: {(muteStatus ? "MUTED" : "UNMUTED")}");

                                    if (!mutes.ContainsKey(playerId) || mutes[playerId] != muteStatus)
                                    {
                                        mutes[playerId] = muteStatus;

                                        if (muteStatus == true)
                                        {
                                            VRCPlayer player = PlayerWrapper.GetPlayerFromPhotonId(playerId);
                                            Chatbox.SendCustomChatMessage($"[Odium] -> {player.field_Private_VRCPlayerApi_0.displayName} MUTED me");
                                            OdiumBottomNotification.ShowNotification($"<color=#7B02FE>{player.field_Private_VRCPlayerApi_0.displayName}</color> <color=red>MUTED</color> you!");
                                            InternalConsole.LogIntoConsole(
                                                $"<color=#31BCF0>[Odium]:</color> <color=#7B02FE>{player.field_Private_VRCPlayerApi_0.displayName}</color> <color=red>MUTED</color> you!"
                                            );
                                        }
                                        else
                                        {
                                            VRCPlayer player = PlayerWrapper.GetPlayerFromPhotonId(playerId);
                                            Chatbox.SendCustomChatMessage($"[Odium] -> {player.field_Private_VRCPlayerApi_0.displayName} unfortunately UNMUTED me");
                                            OdiumBottomNotification.ShowNotification($"<color=#7B02FE>{player.field_Private_VRCPlayerApi_0.displayName}</color> <color=red>UNMUTED</color> you!");
                                            InternalConsole.LogIntoConsole(
                                                $"<color=#31BCF0>[Odium]:</color> <color=#7B02FE>{player.field_Private_VRCPlayerApi_0.displayName}</color> <color=red>UNMUTED</color> you!"
                                            );
                                        }
                                    }
                                }
                            }
                            else
                            {
                                OdiumConsole.LogGradient("PhotonEvent", "  Cached Moderation Event");

                                if (moderationDict.ContainsKey(10))
                                {
                                    var blocks = Il2CppArrayBase<int>.WrapNativeGenericArrayPointer(moderationDict[10].Pointer);
                                    if (blocks != null && blocks.Length > 0)
                                    {
                                        OdiumConsole.LogGradient("PhotonEvent", $"  *** CACHED BLOCKS ({blocks.Length}): ***");
                                        foreach (var blockId in blocks)
                                        {
                                            OdiumConsole.LogGradient("PhotonEvent", $"    Blocked Player: {blockId}");
                                        }
                                    }
                                }

                                if (moderationDict.ContainsKey(11))
                                {
                                    var mutes = Il2CppArrayBase<int>.WrapNativeGenericArrayPointer(moderationDict[11].Pointer);
                                    if (mutes != null && mutes.Length > 0)
                                    {
                                        OdiumConsole.LogGradient("PhotonEvent", $"  Cached Mutes ({mutes.Length}):");
                                        foreach (var muteId in mutes)
                                        {
                                            OdiumConsole.LogGradient("PhotonEvent", $"    Muted Player: {muteId}");
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            OdiumConsole.LogGradient("PhotonEvent", "  Failed to cast moderation dictionary");
                        }
                    }

                    if (param_1.Parameters != null && param_1.Parameters.ContainsKey(254))
                    {
                        var timestamp = param_1.Parameters[254];
                        OdiumConsole.LogGradient("PhotonEvent", $"  Timestamp: {timestamp}");
                    }
                    break;
            }

            return true;
        }
    }
}