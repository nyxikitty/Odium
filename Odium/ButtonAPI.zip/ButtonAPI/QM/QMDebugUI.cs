﻿using Odium.AwooochysResourceManagement;
using Odium.ButtonAPI.QM;
using Odium.Odium;
using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using VRC.UI.Core.Styles;
using Odium.QMPages;
using VRC.Ui;
using static System.Net.Mime.MediaTypeNames;

namespace Odium.ButtonAPI.QM
{
    internal class DebugUI
    {
        // Constants
        private const int MAX_LINES = 33;
        private const int MAX_CHARACTERS_PER_LINE = 68;

        public static GameObject label;
        public static GameObject background;
        public static TextMeshProUGUI text;
        public static List<string> messageList = new List<string>();

        private static readonly Dictionary<string, Color> keywordColors = new Dictionary<string, Color>
        {
            {"Join", Color.green},
            {"Leave", Color.red},
            {"+", Color.green},
            {"-", Color.red},
            {"Debug", Color.yellow},
            {"Log", Color.magenta},
            {"Photon", Color.magenta},
            {"Warn", Color.cyan},
            {"Error", Color.red},
            {"RPC", Color.white}
        };

        public static void InitializeDebugMenu()
        {
            try
            {
                var userInterface = AssignedVariables.userInterface;
                if (userInterface == null)
                {
                    OdiumConsole.Log("DebugUI", "User interface not found");
                    return;
                }

                var dashboardHeader = userInterface.transform.Find("Canvas_QuickMenu(Clone)/CanvasGroup/Container/Window/QMParent/Menu_Dashboard/ScrollRect/Viewport/VerticalLayoutGroup/Header_QuickLinks");
                dashboardHeader.gameObject.SetActive(true);
                dashboardHeader.transform.Find("HeaderBackground").gameObject.SetActive(true);

                if (dashboardHeader == null)
                {
                    OdiumConsole.Log("DebugUI", "Dashboard header template not found");
                    return;
                }

                label = UnityEngine.Object.Instantiate(dashboardHeader.gameObject);
                label.SetActive(true);

                label.transform.SetParent(userInterface.transform.Find("Canvas_QuickMenu(Clone)/CanvasGroup/Container/Window/Wing_Right"));

                label.transform.localPosition = new Vector3(450f, -400f, 0f);
                label.transform.localRotation = Quaternion.identity;
                label.transform.localScale = new Vector3(1f, 1f, 1f);

                var invisibleGraphic = label.GetComponent<UIInvisibleGraphic>();
                if (invisibleGraphic != null)
                    invisibleGraphic.enabled = false;

                text = label.GetComponentInChildren<TextMeshProUGUIEx>();
                if (text == null)
                {
                    OdiumConsole.Log("DebugUI", "Text component not found");
                    return;
                }

                text.alignment = TextAlignmentOptions.TopLeft;
                text.outlineWidth = 0.2f;
                text.fontSize = 20f;
                text.fontSizeMax = 25f;
                text.fontSizeMin = 18f;
                text.richText = true;

                Transform LeftItemContainer = label.transform.Find("LeftItemContainer");
                if (LeftItemContainer != null)
                {
                    var layoutGroup = LeftItemContainer.GetComponent<LayoutGroup>();
                    if (layoutGroup != null)
                    {
                        layoutGroup.enabled = false;
                        OdiumConsole.Log("DebugUI", "Disabled LayoutGroup on LeftItemContainer");
                    }

                    var contentSizeFitter = LeftItemContainer.GetComponent<ContentSizeFitter>();
                    if (contentSizeFitter != null)
                    {
                        contentSizeFitter.enabled = false;
                        OdiumConsole.Log("DebugUI", "Disabled ContentSizeFitter on LeftItemContainer");
                    }
                }

                var labelLayoutGroup = label.GetComponent<LayoutGroup>();
                if (labelLayoutGroup != null)
                {
                    labelLayoutGroup.enabled = false;
                    OdiumConsole.Log("DebugUI", "Disabled LayoutGroup on label");
                }

                if (text != null)
                {
                    RectTransform rectTransform = text.GetComponent<RectTransform>();
                    if (rectTransform != null)
                    {
                        rectTransform.anchoredPosition = new Vector2(180, 390f);
                        OdiumConsole.Log("DebugUI", $"Set anchored position to: {rectTransform.anchoredPosition}");
                    }
                }

                var mask = label.AddComponent<Mask>();
                mask.showMaskGraphic = false;

                background = label.transform.Find("HeaderBackground")?.gameObject;
                if (background == null)
                {
                    OdiumConsole.Log("DebugUI", "Background object not found");
                    return;
                }

                background.transform.localPosition = new Vector3(0f, 0f, 0f);
                background.transform.localScale = new Vector3(0.6f, 10f, 1f);
                background.transform.localRotation = Quaternion.identity;

                background.SetActive(true);

                var bgImage = background.GetComponent<ImageEx>();
                if (bgImage == null)
                {
                    OdiumConsole.Log("DebugUI", "Background image component not found");
                    return;
                }

                string bgPath = System.IO.Path.Combine(Environment.CurrentDirectory, "Odium", "QMDebugUIBackground.png");
                var sprite = bgPath.LoadSpriteFromDisk();
                if (sprite == null)
                {
                    OdiumConsole.Log("DebugUI", $"Failed to load background sprite from path: {bgPath}");
                    bgImage.m_Color = new Color(0.443f, 0.133f, 1.0f, 1.0f);
                }
                else
                {
                    bgImage.overrideSprite = sprite;
                }

                var styleElement = background.GetComponent<StyleElement>();
                if (styleElement != null)
                {
                    UnityEngine.Object.Destroy(styleElement);
                }

                label.SetActive(true);
                background.SetActive(true);

                LogMessage("Debug UI Active!");
                LogMessage("Join Player joined");
                LogMessage("Error Test error message");

                OdiumConsole.Log("DebugUI", "Debug menu positioned correctly!");
            }
            catch (Exception ex)
            {
                OdiumConsole.Log("DebugUI", $"Failed to initialize debug menu: {ex.Message}");
            }
        }

        public static void AdjustPosition(float x, float y, float z)
        {
            if (label != null)
            {
                label.transform.localPosition = new Vector3(x, y, z);
                OdiumConsole.Log("DebugUI", $"Position adjusted to: {x}, {y}, {z}");
            }
        }

        public static void AdjustBackgroundScale(float x, float y, float z)
        {
            if (background != null)
            {
                background.transform.localScale = new Vector3(x, y, z);
                OdiumConsole.Log("DebugUI", $"Background scale adjusted to: {x}, {y}, {z}");
            }
        }

        public static void FixBackgroundWidth()
        {
            if (background != null)
            {
                background.transform.localScale = new Vector3(1f, 8f, 1f);
                OdiumConsole.Log("DebugUI", "Background width adjusted");
            }
        }

        public static string ColorToHex(Color color, bool includeHash = false)
        {
            try
            {
                string r = Mathf.RoundToInt(color.r * 255).ToString("X2");
                string g = Mathf.RoundToInt(color.g * 255).ToString("X2");
                string b = Mathf.RoundToInt(color.b * 255).ToString("X2");

                return includeHash ? $"#{r}{g}{b}" : $"{r}{g}{b}";
            }
            catch (Exception ex)
            {
                OdiumConsole.Log("DebugUI", $"Failed to convert color to hex: {ex.Message}");
                return includeHash ? "#FFFFFF" : "FFFFFF";
            }
        }

        public static string FormatMessage(string message)
        {
            if (string.IsNullOrEmpty(message))
            {
                OdiumConsole.Log("DebugUI", "Message is null or empty");
                return string.Empty;
            }

            try
            {
                string formattedMessage = message;
                if (message.Length > MAX_CHARACTERS_PER_LINE)
                {
                    int lastSpace = message.LastIndexOf(' ', MAX_CHARACTERS_PER_LINE);
                    if (lastSpace == -1) lastSpace = MAX_CHARACTERS_PER_LINE;

                    formattedMessage = message.Substring(0, lastSpace) + "\n" +
                                     FormatMessage(message.Substring(lastSpace + 1));
                }

                // Apply color coding
                foreach (var kvp in keywordColors)
                {
                    if (formattedMessage.Contains(kvp.Key))
                    {
                        string colorTag = $"<color={ColorToHex(kvp.Value)}>";
                        formattedMessage = formattedMessage.Replace(kvp.Key, $"{colorTag}{kvp.Key}</color>");
                    }
                }

                return formattedMessage + "\n";
            }
            catch (Exception ex)
            {
                OdiumConsole.Log("DebugUI", $"Failed to format message: {ex.Message}");
                return message + "\n";
            }
        }

        public static void LogMessage(string message)
        {
            try
            {
                if (messageList.Count >= MAX_LINES)
                {
                    messageList.RemoveAt(0);
                }

                messageList.Add($"{message}\n");
                UpdateDisplay();
            }
            catch (Exception ex)
            {
                OdiumConsole.Log("DebugUI", $"Failed to log message: {ex.Message}");
            }
        }

        private static void UpdateDisplay()
        {
            try
            {
                if (text == null)
                {
                    OdiumConsole.Log("DebugUI", "Text component is null, cannot update display");
                    return;
                }

                text.text = string.Join("", messageList);
            }
            catch (Exception ex)
            {
                OdiumConsole.Log("DebugUI", $"Failed to update display: {ex.Message}");
            }
        }
    }
}