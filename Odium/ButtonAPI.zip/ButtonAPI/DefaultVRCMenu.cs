﻿namespace Odium.ButtonAPI.QM
{
    public enum DefaultVRCMenu
    {
        SelectedUser_Local,
        Dashboard,
        Notifications,
        Camera,
        Here,
        GeneralSettings,
        AudioSettings,
    }
}
